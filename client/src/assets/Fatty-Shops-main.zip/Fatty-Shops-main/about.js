const nav = document.querySelector('.navbar');
const about = document.querySelector('.aboutMobile');

nav.addEventListener('click', () => {
  location.href = 'index.html';
});

scrollTo({ behavior: 'smooth', top: about.offsetHeight + 400 });